/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.soa.ProyectoF.config;

import com.soa.ProyectoF.Services.UsuarioServicio;
import com.soa.ProyectoF.entidad.Categoria;

import com.soa.ProyectoF.entidad.Usuario;
import com.soa.ProyectoF.repositorio.CategoriaRepositorio;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;



@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UsuarioServicio usuarioServicio;

    @Autowired
    private CategoriaRepositorio categoriaRepositorio;

    @Override
    public void run(String... args) throws Exception {
        // Verificar si existe un usuario ADMIN, si no, crearlo
        if (usuarioServicio.findByUsername("admin").isEmpty()) {
            Usuario admin = new Usuario();
            admin.setUsername("admin");
            admin.setPassword("admin123"); // Contraseña sin encriptar
            admin.setEmail("admin@ejemplo.com");
            admin.setRole("ROLE_ADMIN");

            usuarioServicio.save(admin);
            System.out.println("Usuario ADMIN creado: admin");
        }
    }

    @PostConstruct
    public void init() {
        // Crear categorías solo si no existen
        crearCategoria("Postres");
        crearCategoria("Bebidas");
        crearCategoria("Helados");
        crearCategoria("Batidos");
        crearCategoria("Café");
        crearCategoria("Frappuccino");
        crearCategoria("Jugos");
        crearCategoria("Milkshakes");
        crearCategoria("Frozen");
        crearCategoria("Crepe");
    }

    // Método para crear una categoría solo si no existe
    private void crearCategoria(String nombre) {
        if (categoriaRepositorio.findByNombre(nombre).isEmpty()) {
            Categoria categoria = new Categoria();
            categoria.setNombre(nombre);
            categoriaRepositorio.save(categoria);
            System.out.println("Categoría creada: " + nombre);
        } else {
            System.out.println("Categoría ya existe: " + nombre);
        }
    }
}

