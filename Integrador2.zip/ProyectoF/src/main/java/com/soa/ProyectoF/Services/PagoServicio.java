/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.soa.ProyectoF.Services;

import com.soa.ProyectoF.entidad.Carrito;
import com.soa.ProyectoF.entidad.Pago;
import com.soa.ProyectoF.repositorio.CarritoRepositorio;
import com.soa.ProyectoF.repositorio.PagoRepositorio;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PagoServicio {

    @Autowired
    private PagoRepositorio pagoRepositorio;

    @Autowired
    private CarritoRepositorio carritoRepositorio;

    // Realizar el pago
    public void realizarPago(Long carritoId, Double monto) {
        Carrito carrito = carritoRepositorio.findById(carritoId).orElseThrow(() -> new RuntimeException("Carrito no encontrado"));

        Pago pago = new Pago();
        pago.setCarrito(carrito);
        pago.setMonto(monto);
        pago.setFechaPago(new java.util.Date());

        pagoRepositorio.save(pago);
    }
}

