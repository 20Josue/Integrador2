/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.soa.ProyectoF.Controller;

import com.soa.ProyectoF.Services.CarritoServicio;
import com.soa.ProyectoF.Services.VentaServicio;
import com.soa.ProyectoF.entidad.Carrito;
import com.soa.ProyectoF.entidad.CarritoItem;
import com.soa.ProyectoF.repositorio.ProductoRepositorio;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;


@Controller

public class CarritoControlador {
    @Autowired
    private VentaServicio ventaServicio;

    @Autowired
    private CarritoServicio carritoServicio;




    // Mostrar carrito
    @GetMapping("/carrito")
    public Object verCarrito(Model model, HttpServletRequest request) {
        Long usuarioId = obtenerUsuarioId();
        Carrito carrito = carritoServicio.obtenerCarrito(usuarioId);

        if ("XMLHttpRequest".equals(request.getHeader("X-Requested-With"))) {
            return ResponseEntity.ok(carrito);
        } else {
            model.addAttribute("carrito", carrito);
            return "carrito"; // Nombre de la vista Thymeleaf para el carrito
        }
    }

    @GetMapping("/api/carrito")
    public ResponseEntity<Carrito> obtenerCarritoJson() {
        Long usuarioId = obtenerUsuarioId();
        Carrito carrito = carritoServicio.obtenerCarrito(usuarioId);
        return ResponseEntity.ok(carrito);
    }

    // Método auxiliar para obtener el ID del usuario (por ejemplo, desde sesión o seguridad)
    private Long obtenerUsuarioId() {
        return 1L; // Ejemplo, retornar un usuario por defecto
    }

    @PostMapping("/carrito/pagar")
    public String pago(@RequestBody List<CarritoItem> cartItems, HttpSession session) {
        // Guardar el carrito en la sesión
        session.setAttribute("cartItems", cartItems);
        return "redirect:/carrito/pagar";
    }

    // Servicio para registrar ventas

    @GetMapping("/carrito/pagar")
    public String mostrarPago(Model model, HttpSession session) {
        // Obtener el carrito de la sesión
        List<CarritoItem> cartItems = (List<CarritoItem>) session.getAttribute("cartItems");

        // Calcular subtotales y total
        double total = 0;
        StringBuilder detalles = new StringBuilder(); // Para almacenar los detalles de los productos

        if (cartItems != null) {
            for (CarritoItem item : cartItems) {
                total += item.getPrice() * item.getQuantity();
                detalles.append(item.getName())
                        .append(" x ")
                        .append(item.getQuantity())
                        .append(", ");
            }

            // Eliminar la última coma y espacio
            if (detalles.length() > 0) {
                detalles.setLength(detalles.length() - 2);
            }

            // Registrar la venta en la base de datos
            ventaServicio.registrarVenta(total, detalles.toString());

            // Limpiar el carrito después de registrar la venta
            session.removeAttribute("cartItems");
        }

        // Pasar los datos al modelo
        model.addAttribute("cartItems", cartItems);
        model.addAttribute("total", total);

        return "pago"; // Nombre de la vista
    }
}


