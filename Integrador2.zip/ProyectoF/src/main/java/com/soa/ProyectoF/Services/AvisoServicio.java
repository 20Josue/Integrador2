/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.soa.ProyectoF.Services;

import com.soa.ProyectoF.entidad.Aviso;
import com.soa.ProyectoF.repositorio.AvisoRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class AvisoServicio {

    @Autowired
    private AvisoRepository avisoRepository;

    public List<Aviso> listarAvisos() {
        return avisoRepository.findAll();
    }

    public Aviso guardarAviso(Aviso aviso) {
        return avisoRepository.save(aviso);
    }
    public Aviso findById(Long id) {
        return avisoRepository.findById(id).orElse(null);  // Si no se encuentra, devuelve null
    }

    public void eliminarAviso(Long id) {
        avisoRepository.deleteById(id);
    }

    public List<Aviso> obtenerAvisosActivos() {
        return avisoRepository.findAvisosActivos();
    }
}
