/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.soa.ProyectoF.Controller;

import com.soa.ProyectoF.Services.UsuarioServicio;
import com.soa.ProyectoF.entidad.Usuario;
import jakarta.servlet.http.HttpSession;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class UsuarioControlador {

    @Autowired
    private UsuarioServicio usuarioServicio;

    @GetMapping("/login")
    public String showLoginPage() {
        return "login";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "index";
    }

    // Nueva lógica para registro
    @GetMapping("/registro")
    public String showRegisterPage() {
        return "registro"; // Mostrar la página de registro
    }

    @PostMapping("/registro")
    public String register(String username, String password, String email, Model model) {
        // Obtén el Optional<Usuario>
        Optional<Usuario> existingUsuarioOptional = usuarioServicio.findByUsername(username);

        // Verifica si el usuario existe
        if (existingUsuarioOptional.isPresent()) {
            model.addAttribute("error", "El nombre de usuario ya existe");
            return "registro";
        }

        // Crea un nuevo usuario si no existe
        Usuario newUser = new Usuario();
        newUser.setUsername(username);
        newUser.setPassword(password); // Almacena la contraseña sin cifrar (no recomendado en producción)
        newUser.setEmail(email);
        newUser.setRole("USER"); // Cambiado a "USER" sin prefijo de rol

        usuarioServicio.save(newUser);
        return "redirect:/login";
    }

    @PostMapping("/promoteUser")
    public String promoteUser(@RequestParam Long userId) {
        Usuario usuario = usuarioServicio.findById(userId);
        if (usuario != null) {
            usuario.setRole("ADMIN"); // Cambiado a "ADMIN" sin prefijo de rol
            usuarioServicio.save(usuario);
        }
        return "redirect:/admin/users"; // Asegúrate de tener esta ruta
    }

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password, HttpSession session, Model model) {
        Optional<Usuario> optionalUsuario = usuarioServicio.findByUsername(username);

        if (optionalUsuario.isPresent()) {
            Usuario usuario = optionalUsuario.get();
            // Aquí debes comprobar si la contraseña es correcta
            if (usuario.getPassword().equals(password)) { // Asegúrate de que la comparación de contraseñas sea segura
                session.setAttribute("user", usuario.getUsername());
                 session.setAttribute("role", usuario.getRole()); // Guarda el nombre de usuario en la sesión
                return "redirect:/"; // Redirige a la página principal
            }
        }

        model.addAttribute("error", "Usuario o contraseña incorrectos");
        return "login"; // Regresa a la página de login si hay error
    }

}
