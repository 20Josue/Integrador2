/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.soa.ProyectoF.Controller;

import com.soa.ProyectoF.Services.AvisoServicio;
import com.soa.ProyectoF.entidad.Aviso;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.time.format.DateTimeFormatter;
import java.util.List;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RequestMapping("/avisos")
public class AvisoControlador {

    @Autowired
    private AvisoServicio avisoServicio;

    @GetMapping
    public String listarAvisos(Model model) {
        List<Aviso> avisos = avisoServicio.listarAvisos();

        // Formatear las fechas antes de pasarlas al modelo
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        for (Aviso aviso : avisos) {
            if (aviso.getFechaInicio() != null) {
                // Formatear la fecha de inicio
                String fechaInicioFormateada = aviso.getFechaInicio().format(formatter);
                aviso.setFechaInicioFormateada(fechaInicioFormateada);  // Asumiendo que tienes este campo en la entidad Aviso
            }
            if (aviso.getFechaFin() != null) {
                // Formatear la fecha de fin
                String fechaFinFormateada = aviso.getFechaFin().format(formatter);
                aviso.setFechaFinFormateada(fechaFinFormateada);  // Suponiendo que también tienes este campo
            }
        }

        model.addAttribute("avisos", avisos);
        return "/avisos";
    }

    @GetMapping("/crear")
    public String mostrarFormularioCrearAviso(Model model) {
        model.addAttribute("aviso", new Aviso());
        return "/crearAviso";
    }

    @PostMapping("/activar/{id}")
    public String activarAviso(@PathVariable Long id) {
        Aviso aviso = avisoServicio.findById(id);  // Obtén el aviso por ID
        if (aviso != null) {
            aviso.setActivo(!aviso.isActivo());  // Cambia el estado de 'activo'
            avisoServicio.guardarAviso(aviso);  // Guarda el cambio
        }
        return "redirect:/avisos";  // Redirige de nuevo a la lista de avisos
    }

    @PostMapping("/guardar")
    public String guardarAviso(@ModelAttribute Aviso aviso, @RequestParam("imagen") MultipartFile imagen) throws IOException {
        if (!imagen.isEmpty()) {
            // Ruta donde se guardarán las imágenes
            String directorioBase = "src/main/resources/static/images";

            // Asegurarse de que la carpeta exista
            Path directorioRuta = Paths.get(directorioBase);
            if (!Files.exists(directorioRuta)) {
                Files.createDirectories(directorioRuta); // Crear carpeta si no existe
            }

            // Construir la ruta completa del archivo
            String imagenUrl = directorioBase + "\\" + imagen.getOriginalFilename();
            Path rutaImagen = Paths.get(imagenUrl);

            // Guardar la imagen en la carpeta
            Files.write(rutaImagen, imagen.getBytes());

            // Guardar la URL relativa para mostrar la imagen en el frontend
            aviso.setImagenUrl("/images/" + imagen.getOriginalFilename());
        }

        // Guardar el aviso en la base de datos
        avisoServicio.guardarAviso(aviso);

        // Redirigir a la lista de avisos
        return "redirect:/avisos";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarAviso(@PathVariable Long id) {
        avisoServicio.eliminarAviso(id);
        return "redirect:/avisos";
    }
}
