package com.soa.ProyectoF.Controller;

import com.soa.ProyectoF.Services.AvisoServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {
      @Autowired
    private AvisoServicio avisoServicio;

    @GetMapping("/")
    public String index(Model model) {
        // Obtener los avisos activos y agregar al modelo
        model.addAttribute("avisosActivos", avisoServicio.obtenerAvisosActivos());
        
        // Devuelve la vista index.html, que ahora recibirá los datos
        return "index"; 
    }


    @GetMapping("/nosotros")
    public String nosotros() {
        return "nosotros"; // Devuelve la vista nosotros.html
    }
/*
    @GetMapping("/carrito")
    public String carrito() {
        return "carrito"; // Devuelve la vista carrito.html
    }
*/
    @GetMapping("/contactanos")
    public String contactanos() {
        return "contactanos"; // Devuelve la vista contactanos.html
    }
    /*
    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("avisosActivos", avisoServicio.obtenerAvisosActivos());
        return "index";
    }
*/
}