/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.soa.ProyectoF.repositorio;

import com.soa.ProyectoF.entidad.Aviso;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


@Repository
public interface AvisoRepository extends JpaRepository<Aviso, Long> {
    @Query("SELECT a FROM Aviso a WHERE a.activo = true AND CURRENT_DATE BETWEEN a.fechaInicio AND a.fechaFin")
    List<Aviso> findAvisosActivos();
}
