/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.soa.ProyectoF.Services;

import com.soa.ProyectoF.entidad.Venta;
import com.soa.ProyectoF.repositorio.VentaRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class VentaServicio {

    @Autowired
    private VentaRepositorio ventaRepositorio;

    public Venta registrarVenta(double total, String detalles) {
        Venta venta = new Venta();
        venta.setFecha(LocalDateTime.now());
        venta.setTotal(total);
        venta.setDetalles(detalles);
        return ventaRepositorio.save(venta);
    }
    public List<Venta> obtenerTodasLasVentas() {
        return ventaRepositorio.findAll();
    }
}
