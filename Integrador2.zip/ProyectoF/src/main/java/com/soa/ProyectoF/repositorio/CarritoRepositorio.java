/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.soa.ProyectoF.repositorio;

import com.soa.ProyectoF.entidad.Carrito;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CarritoRepositorio extends JpaRepository<Carrito, Long> {
    // Buscar el carrito de un usuario específico
    Carrito findByUsuarioId(Long usuarioId);
}

