/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.soa.ProyectoF.Services;

import com.soa.ProyectoF.entidad.Carrito;
import com.soa.ProyectoF.repositorio.CarritoRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CarritoServicio {

    @Autowired
    private CarritoRepositorio carritoRepositorio;

    public Carrito obtenerCarrito(Long usuarioId) {
        return carritoRepositorio.findByUsuarioId(usuarioId); // Asegúrate de que tienes un método para encontrar el carrito por usuario
    }
    
    public void realizarPago(Long carritoId, Double montoTotal) {
        // Implementación del pago y actualización del estado del carrito
    }
}




