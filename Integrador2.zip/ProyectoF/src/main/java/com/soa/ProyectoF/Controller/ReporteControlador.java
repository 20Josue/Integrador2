/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.soa.ProyectoF.Controller;

import com.soa.ProyectoF.Services.VentaServicio;
import com.soa.ProyectoF.entidad.Venta;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

@Controller
public class ReporteControlador {

    @Autowired
    private VentaServicio ventaServicio;

    @GetMapping("/reporteVentas")
    public ResponseEntity<byte[]> generarReporteVentas() throws IOException {
        // Obtener todas las ventas
        List<Venta> ventas = ventaServicio.obtenerTodasLasVentas();

        // Crear el archivo Excel
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Reporte de Ventas");

        // Crear el encabezado
        Row header = sheet.createRow(0);
        header.createCell(0).setCellValue("ID");
        header.createCell(1).setCellValue("Fecha");
        header.createCell(2).setCellValue("Total");
        header.createCell(3).setCellValue("Detalles");

        // Estilo para el encabezado
        CellStyle headerStyle = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        headerStyle.setFont(font);
        for (Cell cell : header) {
            cell.setCellStyle(headerStyle);
        }

        // Llenar datos de las ventas
        int rowIndex = 1;
        for (Venta venta : ventas) {
            Row row = sheet.createRow(rowIndex++);
            row.createCell(0).setCellValue(venta.getId());
            row.createCell(1).setCellValue(venta.getFecha().toString());
            row.createCell(2).setCellValue(venta.getTotal());
            row.createCell(3).setCellValue(venta.getDetalles());
        }

        // Ajustar columnas
        for (int i = 0; i < 4; i++) {
            sheet.autoSizeColumn(i);
        }

        // Escribir el archivo a un ByteArrayOutputStream
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        workbook.write(outputStream);
        workbook.close();

        // Crear el archivo para la descarga
        byte[] excelFile = outputStream.toByteArray();
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=reporte_ventas.xlsx");

        return ResponseEntity.ok()
                .headers(headers)
                .body(excelFile);
    }
}
