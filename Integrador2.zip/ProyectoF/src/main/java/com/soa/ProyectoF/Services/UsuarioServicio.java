/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.soa.ProyectoF.Services;

import com.soa.ProyectoF.entidad.Usuario;
import com.soa.ProyectoF.repositorio.UsuarioRepositorio;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UsuarioServicio {

    @Autowired
    private UsuarioRepositorio usuarioRepositorio;

    // Cambia el tipo de retorno a Optional<Usuario>
    public Optional<Usuario> findByUsername(String username) {
        return usuarioRepositorio.findByUsername(username);
    }

    public void save(Usuario usuario) {
        usuarioRepositorio.save(usuario);
    }

    public Usuario findById(Long id) {
        return usuarioRepositorio.findById(id).orElse(null); // Devuelve null si no se encuentra
    }

    public List<Usuario> listarTodos() {
        return usuarioRepositorio.findAll();
    }

    public void eliminarPorId(Long id) {
        usuarioRepositorio.deleteById(id);
    }
}
