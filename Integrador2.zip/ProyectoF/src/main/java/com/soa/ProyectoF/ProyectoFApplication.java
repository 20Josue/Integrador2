package com.soa.ProyectoF;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoFApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoFApplication.class, args);
	}

}
