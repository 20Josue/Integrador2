/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.soa.ProyectoF.Services;

import com.soa.ProyectoF.entidad.Producto;
import com.soa.ProyectoF.repositorio.ProductoRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductoServicio {

    @Autowired
    private ProductoRepositorio productoRepositorio;

    // Método para listar todos los productos
    public List<Producto> listarProductos() {
        return productoRepositorio.findAll();
    }

    // Método para guardar un nuevo producto
    public Producto guardarProducto(Producto producto) {
        return productoRepositorio.save(producto);
    }

    // Método para encontrar un producto por ID
    public Producto encontrarProductoPorId(Long id) {
        return productoRepositorio.findById(id).orElse(null); // Retorna null si no se encuentra
    }

    // Método para eliminar un producto por ID
    public void eliminarProducto(Long id) {
        productoRepositorio.deleteById(id);
    }

    // Método para actualizar un producto existente
    public Producto actualizarProducto(Long id, Producto productoActualizado) {
        Producto productoExistente = encontrarProductoPorId(id);
        if (productoExistente != null) {
            productoExistente.setNombre(productoActualizado.getNombre());
            productoExistente.setPrecio(productoActualizado.getPrecio());
            productoExistente.setImagenUrl(productoActualizado.getImagenUrl());
            productoExistente.setCategoria(productoActualizado.getCategoria());
            return productoRepositorio.save(productoExistente);
        }
        return null; // Retorna null si no se encuentra el producto
    }
}


