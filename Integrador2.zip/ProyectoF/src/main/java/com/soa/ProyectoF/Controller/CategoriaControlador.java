/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.soa.ProyectoF.Controller;

import com.soa.ProyectoF.Services.CategoriaServicio;
import com.soa.ProyectoF.entidad.Categoria;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CategoriaControlador {

    @Autowired
    private CategoriaServicio categoriaServicio;

    // Método para listar categorías
    @GetMapping("/categorias") // Cambia la ruta si no quieres que sea solo para admin
    public String listarCategorias(Model model) {
        model.addAttribute("categorias", categoriaServicio.listarCategorias());
        return "categorias";
    }

    // Método para agregar una nueva categoría
    @PostMapping("/categorias/agregar") // Cambia la ruta si no quieres que sea solo para admin
    public String agregarCategoria(@RequestParam("nombreCategoria") String nombreCategoria) {
        Categoria categoria = new Categoria();
        categoria.setNombre(nombreCategoria);
        categoriaServicio.guardarCategoria(categoria);
        return "redirect:/categorias"; // Cambia la ruta si no quieres que sea solo para admin
    }

    // Método para eliminar una categoría
    @GetMapping("/categorias/eliminar") // Cambia la ruta si no quieres que sea solo para admin
    public String eliminarCategoria(@RequestParam("id") Long id) {
        categoriaServicio.eliminarCategoria(id);
        return "redirect:/categorias"; // Cambia la ruta si no quieres que sea solo para admin
    }

    @PostMapping("/admin/categorias/agregar")
    public String agregarCategoria(@RequestParam("nombreCategoria") String nombreCategoria, Model model) {
        if (nombreCategoria == null || nombreCategoria.trim().isEmpty()) {
            model.addAttribute("error", "El nombre de la categoría no puede estar vacío.");
            return "categorias"; // Regresa a la vista de categorías con un error
        }

        if (nombreCategoria.length() < 2 || nombreCategoria.length() > 50) {
            model.addAttribute("error", "El nombre debe tener entre 2 y 50 caracteres.");
            return "categorias"; // Regresa a la vista de categorías con un error
        }

        Categoria categoria = new Categoria();
        categoria.setNombre(nombreCategoria);
        categoriaServicio.guardarCategoria(categoria);
        return "redirect:/admin/categorias";
    }

}
