/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.soa.ProyectoF.Controller;

import com.soa.ProyectoF.Services.ProductoServicio;
import com.soa.ProyectoF.Services.CategoriaServicio;
import com.soa.ProyectoF.entidad.Producto;
import com.soa.ProyectoF.entidad.Categoria;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

@Controller
public class ProductoControlador {

    @Autowired
    private ProductoServicio productoServicio;

    @Autowired
    private CategoriaServicio categoriaServicio;

    // Ruta base relativa para las imágenes
    private static final String RUTA_IMAGENES = "src/main/resources/static/images";

    // Método para listar productos para usuarios normales y administradores
    @GetMapping("/productos")
    public String listarProductosPublico(HttpSession session, Model model) {
        model.addAttribute("productos", productoServicio.listarProductos());
        model.addAttribute("categorias", categoriaServicio.listarCategorias());

        // Verificar si el usuario tiene el rol de administrador
        String role = (String) session.getAttribute("role");
        boolean isAdmin = role != null && role.equals("ROLE_ADMIN");
        model.addAttribute("isAdmin", isAdmin); // Pasar el valor a la vista
        return "productos"; // La vista se llama 'productos.html'
    }

    // Método para listar productos solo para administradores
    @GetMapping("/admin/productos")
    public String listarProductosAdmin(HttpSession session, Model model) {
        String role = (String) session.getAttribute("role");
        if (role == null || !role.equals("ROLE_ADMIN")) {
            return "redirect:/productos"; // Redirigir si no es admin
        }

        model.addAttribute("productos", productoServicio.listarProductos());
        model.addAttribute("categorias", categoriaServicio.listarCategorias());
        model.addAttribute("isAdmin", true); // Indicar que es admin en la vista
        return "productos";
    }

    // Método para mostrar el formulario de agregar producto
    @GetMapping("/admin/productos/agregar")
    public String mostrarFormularioAgregarProducto(HttpSession session, Model model) {
        String role = (String) session.getAttribute("role");
        if (role == null || !role.equals("ROLE_ADMIN")) {
            return "redirect:/productos"; // Redirigir si no es admin
        }

        // Obtener la lista de nombres de imágenes en la carpeta relativa
        List<String> nombresImagenes = obtenerNombresDeImagenes();
        model.addAttribute("nombresImagenes", nombresImagenes);
        model.addAttribute("categorias", categoriaServicio.listarCategorias());
        return "agregarProducto";
    }

    // Método para eliminar un producto
    @GetMapping("/admin/productos/eliminar")
    public String eliminarProducto(@RequestParam("id") Long id) {
        productoServicio.eliminarProducto(id);
        return "redirect:/admin/productos";
    }

    // Método para mostrar el formulario de edición
    @GetMapping("/admin/productos/editar")
    public String mostrarFormularioEdicion(@RequestParam("id") Long id, HttpSession session, Model model) {
        String role = (String) session.getAttribute("role");
        if (role == null || !role.equals("ROLE_ADMIN")) {
            return "redirect:/productos";
        }

        Producto producto = productoServicio.encontrarProductoPorId(id);
        if (producto == null) {
            return "redirect:/admin/productos";
        }

        List<String> nombresImagenes = obtenerNombresDeImagenes();
        model.addAttribute("producto", producto);
        model.addAttribute("categorias", categoriaServicio.listarCategorias());
        model.addAttribute("nombresImagenes", nombresImagenes);

        return "editarProducto";
    }

    // Método para actualizar un producto
    @PostMapping("/admin/productos/actualizar")
    public String actualizarProducto(
            @RequestParam("id") Long id,
            @RequestParam("nombreProducto") String nombreProducto,
            @RequestParam("precioProducto") double precioProducto,
            @RequestParam("categoriaProducto") Long categoriaId,
            @RequestParam("nombreImagen") String nombreImagen,
            HttpSession session) {

        String role = (String) session.getAttribute("role");
        if (role == null || !role.equals("ROLE_ADMIN")) {
            return "redirect:/productos";
        }

        Producto producto = productoServicio.encontrarProductoPorId(id);
        if (producto == null) {
            return "redirect:/admin/productos";
        }

        producto.setNombre(nombreProducto);
        producto.setPrecio(precioProducto);

        Categoria categoria = categoriaServicio.listarCategorias().stream()
                .filter(c -> c.getId().equals(categoriaId))
                .findFirst()
                .orElse(null);
        if (categoria == null) {
            return "redirect:/admin/productos/editar?id=" + id + "&error=categoriaNoValida";
        }
        producto.setCategoria(categoria);

        if (!esImagenValida(nombreImagen)) {
            return "redirect:/admin/productos/editar?id=" + id + "&error=imagenNoEncontrada";
        }
        producto.setImagenUrl(nombreImagen);

        productoServicio.guardarProducto(producto);

        return "redirect:/admin/productos";
    }

    // Método para agregar un producto
    @PostMapping("/admin/productos/agregar")
    public String agregarProducto(
            @RequestParam("nombreProducto") String nombreProducto,
            @RequestParam("precioProducto") double precioProducto,
            @RequestParam("categoriaProducto") Long categoriaId,
            @RequestParam("nombreImagen") String nombreImagen,
            HttpSession session) {

        String role = (String) session.getAttribute("role");
        if (role == null || !role.equals("ROLE_ADMIN")) {
            return "redirect:/productos";
        }

        Producto producto = new Producto();
        producto.setNombre(nombreProducto);
        producto.setPrecio(precioProducto);

        Categoria categoria = categoriaServicio.listarCategorias().stream()
                .filter(c -> c.getId().equals(categoriaId))
                .findFirst()
                .orElse(null);
        if (categoria == null) {
            return "redirect:/admin/productos/agregar?error=categoriaNoValida";
        }
        producto.setCategoria(categoria);

        if (!esImagenValida(nombreImagen)) {
            return "redirect:/admin/productos/agregar?error=imagenNoEncontrada";
        }
        producto.setImagenUrl(nombreImagen);

        productoServicio.guardarProducto(producto);

        return "redirect:/admin/productos";
    }

    @GetMapping("/paginaTienda")
    public String mostrarPaginaTienda(HttpSession session, Model model) {
        model.addAttribute("productos", productoServicio.listarProductos());
        model.addAttribute("categorias", categoriaServicio.listarCategorias());

        String role = (String) session.getAttribute("role");
        boolean isAdmin = role != null && role.equals("ROLE_ADMIN");
        model.addAttribute("isAdmin", isAdmin);

        return "paginaTienda";
    }

    // Método auxiliar para obtener nombres de imágenes desde la carpeta
    private List<String> obtenerNombresDeImagenes() {
        List<String> nombresImagenes = new ArrayList<>();
        File carpetaImagenes = new File(RUTA_IMAGENES);

        if (carpetaImagenes.exists() && carpetaImagenes.isDirectory()) {
            File[] archivos = carpetaImagenes.listFiles((dir, name) -> 
                name.toLowerCase().endsWith(".jpg") || name.toLowerCase().endsWith(".png"));
            if (archivos != null) {
                for (File archivo : archivos) {
                    nombresImagenes.add(archivo.getName());
                }
            }
        }

        return nombresImagenes;
    }

    // Método auxiliar para verificar si una imagen es válida
    private boolean esImagenValida(String nombreImagen) {
        File archivoImagen = new File(RUTA_IMAGENES + "/" + nombreImagen);
        return archivoImagen.exists() && !archivoImagen.isDirectory();
    }
}
