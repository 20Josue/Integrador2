/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.soa.ProyectoF.repositorio;

import com.soa.ProyectoF.entidad.Categoria;
import com.soa.ProyectoF.entidad.Producto;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author JORDAN
 */
public interface ProductoRepositorio extends JpaRepository<Producto, Long> {
     List<Producto> findByCategoriaId(Long categoriaId);
      Optional<Producto> findByNombreAndCategoria(String nombre, Categoria categoria);
}
