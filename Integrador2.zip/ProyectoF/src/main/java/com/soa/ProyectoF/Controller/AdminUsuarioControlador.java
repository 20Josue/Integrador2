/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.soa.ProyectoF.Controller;

import com.soa.ProyectoF.Services.UsuarioServicio;
import com.soa.ProyectoF.entidad.Usuario;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 *
 * @author JORDAN
 */
@Controller
@RequestMapping("/usuarios")
public class AdminUsuarioControlador {

    @Autowired
    private UsuarioServicio usuarioServicio;

    @GetMapping
    public String listarUsuarios(Model model) {
        model.addAttribute("usuarios", usuarioServicio.listarTodos());
        return "/usuarios";
    }

    @PostMapping("/agregar")
    public String agregarUsuario(@RequestParam String username, @RequestParam String password,
                                 @RequestParam String email, @RequestParam String role, Model model) {
        Optional<Usuario> usuarioExistente = usuarioServicio.findByUsername(username);

        if (usuarioExistente.isPresent()) {
            model.addAttribute("error", "El usuario ya existe");
            return "redirect:/admin/usuarios";
        }

        Usuario nuevoUsuario = new Usuario();
        nuevoUsuario.setUsername(username);
        nuevoUsuario.setPassword(password); // Recuerda encriptar la contraseña en producción
        nuevoUsuario.setEmail(email);
        nuevoUsuario.setRole(role);

        usuarioServicio.save(nuevoUsuario);
        return "redirect:/usuarios";
    }

    @PostMapping("/eliminar")
    public String eliminarUsuario(@RequestParam Long id) {
        usuarioServicio.eliminarPorId(id);
        return "redirect:/usuarios";
    }
}
